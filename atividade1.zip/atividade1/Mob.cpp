#include "Mob.hpp"
#include "Entity.hpp"

Mob::Mob(std::string aMobName, int aMaxLife, int aDamage, int aArmor): Entity(aMobName, aMaxLife, aDamage, aArmor) { }
