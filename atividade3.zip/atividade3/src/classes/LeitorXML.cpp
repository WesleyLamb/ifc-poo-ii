#include "LeitorXML.hpp"

#include <string>
#include <iostream>

void LeitorXML::importar(std::string aPath) {
    std::cout << "lalala estou importando um xml: " << aPath << std::endl;
}