#include "LeitorJson.hpp"
#include <iostream>

void LeitorJson::importar(std::string aPath) {
    std::cout << "lalala estou importando um json: " << aPath << std::endl;
}